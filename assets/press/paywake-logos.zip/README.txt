LOGO PLACEMENT
The Paywake Sun logo only should ever be placed on a white (#FFFFF) background.

COMPANY GRADIENT COLORS
Paywake Orange - #FFCC00
Paywake Red - #FF0000
Paywake Purple - #6600FF

COMPANY FONT
Urbanist Semi-Bold 600
https://fonts.google.com/specimen/Urbanist
